Remarques : nous n'avons pas ajouté le repertoire node_modules (serveur) dans le repertoire /src/server comme demandé dans la consigne, ainsi que le node_modules de /src/ (client).

Utilisation et téléchargement de Node js, bcrypt, MongoDB avec compass, React et Express.

