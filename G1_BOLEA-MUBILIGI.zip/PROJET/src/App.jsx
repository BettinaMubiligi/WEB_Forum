import { useState } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import AuthPage from "./auth/PageLogin";
import Header from "./header/Header";
import MainPage from "./components/MainPage";
import MainPageF from "./components/MainPageF";
import "./App.css";


//Composant principal : APP qui va appeler la page par defaut (login) et les autres pages
//MainPage et MainPageF pour les utilisateurs et admins
function App() {
  // on récupèere le rôle depuis localStorage 
  const role = localStorage.getItem("role");
  const [filter, setFilter] = useState("");
  return (
    <BrowserRouter> 
      <Header onFilter={setFilter} /> 
      <Routes>
        {/*  page d'authentification/login par défaut*/ }
        <Route path="/" element={<Navigate to="/auth" />} />
        <Route path="/auth" element={<AuthPage />} />
        {/* route forum ouvert */}
        <Route path="/main" element={<MainPage filter={filter} />} />
        {/* route forum fermé pour admin */}
        <Route path="/admin" element={role === "admin" ? <MainPageF filter={filter} /> : <Navigate to="/main" />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
