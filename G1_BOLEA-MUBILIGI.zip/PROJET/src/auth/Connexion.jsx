import { useState } from "react";
import axios from "axios";
import "./Connexion.css";
import { useNavigate } from "react-router-dom";



//composant de Formulaire de connexion
function SignInForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const navigate = useNavigate(); 

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage("");
    try {
      const res = await axios.post("http://localhost:3001/api/users/login", {
        email,
        password,
      });
      const { token, user } = res.data;

      if (!user.isValidated) {
        setMessage("Votre compte est en attente de validation par un administrateur.");
        return;
      }
      //on stocke les identifiants pour les utiliser + tard (et bdd)
      localStorage.setItem("token", token);
      localStorage.setItem("role", user.isAdmin ? "admin" : "membre");
      localStorage.setItem("user", JSON.stringify(user));
      //Message de Connexion (boîte de connexion)
      setMessage("Connexion réussie !");
      if (user.isAdmin) {
        navigate("/admin");
      } else {
        navigate("/main");
      }
    } catch (err) {
      setMessage(
        //message d'erreur
        err.response?.data?.message || "Erreur lors de la connexion."
      );
    }
  };

  //Formulaire renvoyé demande d'entrer un mail et un mdp
  return (
    <form onSubmit={handleSubmit} className="auth-form">
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
      />
      <input
        type="password"
        placeholder="Mot de passe"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
      />
      <button type="submit">Connexion</button>
      {message && <p>{message}</p>}
    </form>
  );
}

export default SignInForm;
