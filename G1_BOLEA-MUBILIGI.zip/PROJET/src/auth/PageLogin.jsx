import { useState } from "react";
import SignInForm from "./Connexion";
import SignUpForm from "./Enregistrement";
import "./PageLogin.css";

//composant d'authentification
function AuthPage() {
  const [isSignIn, setIsSignIn] = useState(true);

  return (
    <div className="auth-container">
      <h2>{isSignIn ? "Connexion" : "Créer un compte"}</h2>
      <div className="auth-buttons">
        <button onClick={() => setIsSignIn(true)}>Connexion</button>
        <button onClick={() => setIsSignIn(false)}>Inscription</button>
      </div>
      {isSignIn ? <SignInForm /> : <SignUpForm />}
    </div>
  );
}

export default AuthPage;
