import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./MainPage.css";
import MessageList from "./MessageListe";
import MessageForm from "./MessageForm";
import Profile from "./Profile";


//Composant Page principale du forum ouvert, pour les membres (qui prend un propos filtre)
const MainPage = ({ filter }) => { //filter sert à filtrer les messages du composant MainPage
  const storedUser = localStorage.getItem("user");
  let user = storedUser ? JSON.parse(storedUser) : null;

  //on teste l'identité de l'utilisateur pour l'utiliser dans les informations perso
  if (user && !user.role) {
    user = {
      ...user,
      role: user.isAdmin ? "Administrateur" : "Membre",
    };
  }
//hook UseState utilisé pour les messages (tableau de message vide au début)
  const [userMessages, setUserMessages] = useState([]);
  const [allMessages, setAllMessages] = useState([]);
  const navigate = useNavigate();

//Fonction pour récupéerer les messages avec l'api (les membres ne peuvent voir que les messages du forum ouvert)
  const fetchMessages = () => {
    if (user) {
      fetch(`http://localhost:3001/api/messages?author=${encodeURIComponent(user.email)}&forumType=open`)
        .then(res => res.json())
        .then(setUserMessages);

      fetch('http://localhost:3001/api/messages?forumType=open')
        .then(res => res.json())
        .then(setAllMessages);
    }
  };

  useEffect(() => {
    fetchMessages();
  }, [user]);

  //fontion de gestion des messages
  const handleAddMessage = async (content) => {
    const msg = {
      content,
      authorEmail: user.email,
      authorRole: user.role,
      forumType: "open",
    };
    const response = await fetch('http://localhost:3001/api/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(msg),
    });
    await response.json();
    fetchMessages();
  };

  //méthode de suppression des messages 
  const handleDeleteMessage = async (message) => {
    if (!window.confirm("Supprimer ce message ?")) return;
    await fetch(`http://localhost:3001/api/messages/${message._id}?authorEmail=${encodeURIComponent(user.email)}`, {
      method: 'DELETE'
    });
    fetchMessages();
  };

  //gestion de la déconnexion
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    localStorage.removeItem("user");
    navigate("/auth"); ///ramène à la page de Login
  };

  /* Filtrage des messages pour l'aside : par mot clé (peut importe en maj ou min), 
   On met les messages en minuscule pour comparer les mots clés,
     et on renvoie une liste de messages avec ceux qui correspondent aux mots clés puis les autres
 */
  const lowerFilter = filter ? filter.toLowerCase() : "";
  const matchingMessages = (allMessages || []).filter(msg =>
    lowerFilter && msg.content.toLowerCase().includes(lowerFilter)
  );
 
  const nonMatchingMessages = (allMessages || []).filter(msg =>
    !lowerFilter || !msg.content.toLowerCase().includes(lowerFilter)
  );
  const filteredMessages = [...matchingMessages, ...nonMatchingMessages];
  

  if (!user) {
    navigate("/auth");
    return null;
  }

  //page renvoyéee selon le format du projet 
  return (
    <div className="page-container">
      <main className="main">
        <section className="message-form-section">
          <h2>Brisez la glace</h2>
          <MessageForm onAddMessage={handleAddMessage} />
        </section>
        <section id="user_messages">
          <h2>Vos derniers messages</h2>
          <MessageList messages={userMessages} onDelete={handleDeleteMessage} user={user} />
        </section>
      </main>
      <aside className="aside-membre">
        <Profile user={user} allMessages={filteredMessages} onReply={fetchMessages} onDelete={handleDeleteMessage} />
        <div className="aside-spacer" />
        <button className="logout-btn" onClick={handleLogout}>
          Déconnexion
        </button>
      </aside>
    </div>
  );
};

export default MainPage;
