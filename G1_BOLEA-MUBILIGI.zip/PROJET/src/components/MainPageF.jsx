import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import MessageList from "./MessageListe";
import MessageForm from "./MessageForm";
import Profile from "./Profile";
import "./MainPageF.css";


//Composant Page priincipale du forum FERME, pour les amin (qui prend un propos filtre)
//Même principe que le forum ouvert
//Messages ps visibles pour les membres du forum ouvert 


export default function MainPageF({ filter }) {
  const storedUser = localStorage.getItem("user");
  let user = storedUser ? JSON.parse(storedUser) : null;
  if (user && !user.role) {
    user = {
      ...user,
      role: user.isAdmin ? "Administrateur" : "Membre",
    };
  }

  const [userMessages, setUserMessages] = useState([]);
  const [allMessages, setAllMessages] = useState([]);
  const [pendingUsers, setPendingUsers] = useState([]);
  const navigate = useNavigate();

  const fetchMessages = () => {
    if (user) {
      //  messages postés ( dans le forum fermé)
      fetch(`http://localhost:3001/api/messages?author=${encodeURIComponent(user.email)}&forumType=closed`)
        .then(res => res.json())
        .then(setUserMessages);

      // accès à tous les messages dans le Profile (admin = tout, membre = seulement ceux du forum ouvert)
      
        fetch('http://localhost:3001/api/messages?forumType=open')
          .then(res => res.json())
          .then(setAllMessages);

    }
  };

  useEffect(() => {
    fetch("http://localhost:3001/api/admin/pending-users")
      .then(res => res.json())
      .then(setPendingUsers)
      .catch(err => {
        console.error("Erreur lors du fetch des users en attente :", err);
        setPendingUsers([]);
      });
  }, []);

  useEffect(() => {
    fetchMessages();
  }, [user]);

  const handleAddMessage = async (content) => {
    const msg = {
      content,
      authorEmail: user.email,
      authorRole: user.role,
      forumType: "closed",
    };
    const response = await fetch('http://localhost:3001/api/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(msg),
    });
    await response.json();
    fetchMessages();
  };

  const handleDeleteMessage = async (message) => {
    if (!window.confirm("Supprimer ce message ?")) return;
    await fetch(`http://localhost:3001/api/messages/${message._id}?authorEmail=${encodeURIComponent(user.email)}`, {
      method: 'DELETE'
    });
    fetchMessages();
  };

  //fonction en + : pour gérer la validation des nouveaux utilisateurs
  //change le statut isValidate en true ds la BDD

  const handleValidate = (userId, validate) => {
    fetch("http://localhost:3001/api/admin/validate-user", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, validate }),
    })
      .then(res => res.json())
      .then(() => {
        setPendingUsers((users) => users.filter(u => u._id !== userId));
      });
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    localStorage.removeItem("user");
    navigate("/auth");
  };

  // Filtrage des messages pour l'aside  de Prfile
  const lowerFilter = filter ? filter.toLowerCase() : "";
  const matchingMessages = (allMessages || []).filter(msg =>
    lowerFilter && msg.content.toLowerCase().includes(lowerFilter)
  );
  const nonMatchingMessages = (allMessages || []).filter(msg =>
    !lowerFilter || !msg.content.toLowerCase().includes(lowerFilter)
  );
  const filteredMessages = [...matchingMessages, ...nonMatchingMessages];
  

  if (!user) {
    navigate("/auth");
    return null;
  }

  return (
    <div className="page-container">
      <main className="main">
        <section className="message-form-section">
          <h2>Forum fermé (administrateur)</h2>
          <MessageForm onAddMessage={handleAddMessage} />
        </section>
        <section id="user_messages">
          <h2>Vos derniers messages</h2>
          <MessageList messages={userMessages} onDelete={handleDeleteMessage} user={user} />
        </section>
        <section className="admin-requests">
          <h2>Demandes d'inscription</h2>
          {pendingUsers.length === 0 ? (
            <p>Aucune demande en attente.</p>
          ) : (
            <ul>
              {pendingUsers.map(u => (
                <li key={u._id}>
                  {u.email}
                  <button onClick={() => handleValidate(u._id, true)}>Accepter</button>
                  <button onClick={() => handleValidate(u._id, false)}>Refuser</button>
                </li>
              ))}
            </ul>
          )}
        </section>
      </main>
      <aside className="aside-admin">
        <Profile user={user} allMessages={filteredMessages} onReply={fetchMessages} onDelete={handleDeleteMessage} />
        <div className="aside-spacer" />
        <button className="logout-btn" onClick={handleLogout}>
          Déconnexion
        </button>
      </aside>
    </div>
  );
}
