import React, { useState } from "react";
import "./MessageForm.css";


//Composant pour poster un message 
const MessageForm = ({ onAddMessage }) => {
  const [content, setContent] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (content.trim()) {
      onAddMessage(content); // Appel de la fonction parent pour ajouter un message
      setContent(""); // on réinitialise du champ de texte
    }
  };

  return (
    <form className="message-form" onSubmit={handleSubmit}>
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="Écrivez votre message..."
        aria-label="Zone d'écriture de message"
      />
      <button type="submit" className="submit-button">
        Publier
      </button>
    </form>
  );
};

export default MessageForm;
