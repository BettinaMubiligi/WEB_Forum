import React from "react";
import "./MessageListe.css";


//gestion d'un message (création + handlers de suppresion et réponse)
const MessageItem = ({ message, onReply, allMessages, onDelete, user }) => {
  const replies = allMessages
    ? allMessages.filter((m) => m.replyTo === (message._id || message.id))
    : [];
  const isMine = user && message.authorEmail === user.email;

  return (
    <li className="message-item">
      <p className="message-content">{message.content}</p>
      <div className="message-meta">
        <strong>{message.authorEmail}</strong>
        <em>{new Date(message.date).toLocaleString()}</em>
      </div>
      {onReply && (
        <button onClick={() => onReply(message)}>Répondre</button>
      )}
      {isMine && onDelete && (
        <button onClick={() => onDelete(message)} style={{ marginLeft: 8, color: "red" }}>
          Supprimer
        </button>
      )}
      {replies.length > 0 && (
        <ul className="replies-list">
          {replies.map((reply) => (
            <li key={reply._id} className="reply-item">
              <p>{reply.content}</p>
              <div>
                <strong>{reply.authorEmail}</strong>
                <em>{new Date(reply.date).toLocaleString()}</em>
              </div>
            </li>
          ))}
        </ul>
      )}
    </li>
  );
};


//fonction d'affchage de message : Affiche un message et ses éventuelles réponses
//Liste de MessageItems avec les props/handler pour gérer la suppresion, la réponse etc
const MessageList = ({ messages, onReply, allMessages, onDelete, user }) => (
  <ul className="message-list">
    {messages.length > 0 ? (
      messages.map((msg) => (
        <MessageItem
          key={msg._id || msg.id}
          message={msg}
          onReply={onReply}
          allMessages={allMessages || messages}
          onDelete={onDelete}
          user={user}
        />
      ))
    ) : (
      <p>Aucun message pour le moment.</p>
    )}
  </ul>
);

export default MessageList;

