import React, { useState } from "react";
import {
  Grid,
  Typography,
  Paper
} from "@mui/material";
import MessageList from "./MessageListe"; 
import "./Profile.css";


//composant de compte qui prend un utilisateur en props
function Account({ user }) {
  //on affiche les infos perso (mail + role dans le forum selon le prop user)
  if (!user) return null;
  return (
    <Paper>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <Typography variant="h5">Informations personnelles</Typography>
        </Grid>
        <Grid item xs={12}>
          <Typography variant="body1">
            <b>Rôle :</b> {user.role}
          </Typography>
        </Grid>
        <Grid item xs={12}>
          <Typography variant="body1">
            <b>Email :</b> {user.email}
          </Typography>
        </Grid>
      </Grid>
    </Paper>
  );
}

//composant de profile (aside)
export default function Profile({ user, allMessages, onReply, onDelete }) {
  const [replyTo, setReplyTo] = useState(null);
  const [replyContent, setReplyContent] = useState("");

  // fonction pour envoyer la réponse
  const handleReplySubmit = async (e) => {
    e.preventDefault();
    if (!replyContent.trim() || !replyTo) return;

    const msg = {
      content: replyContent,
      authorEmail: user.email,
      authorRole: user.role,
      forumType: replyTo.forumType,
      replyTo: replyTo._id,
    };

    await fetch('http://localhost:3001/api/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(msg),
    });

    setReplyTo(null);
    setReplyContent("");
    if (onReply) onReply(); // on utilise un callback pour rafraichir les messages
  };


  //on renvoie une barre latérale avec tous les messages (forum ouvert pour les membres et tous le forum pour les admins)
  return (
    <Grid container direction="column" justifyContent="center" spacing={3}>
      <Grid item>
        <Account user={user} />
      </Grid>
      <Grid item>
        <Typography variant="h5" gutterBottom>
          Messages
        </Typography>
        <MessageList
          messages={allMessages || []}
          onReply={setReplyTo}
          allMessages={allMessages}
          onDelete={onDelete}
          user={user}
        />
        {replyTo && (
          <form onSubmit={handleReplySubmit} style={{ marginTop: 10 }}>
            <Typography variant="body2">
              Répondre à <b>{replyTo.authorEmail}</b> :<br/>
              <i>{replyTo.content}</i>
            </Typography>
            <textarea
              value={replyContent}
              onChange={e => setReplyContent(e.target.value)}
              placeholder="Votre réponse..."
              style={{ width: "100%", minHeight: 40, marginTop: 5 }}
            />
            <button type="submit">Envoyer la réponse</button>
            <button type="button" onClick={() => setReplyTo(null)} style={{ marginLeft: 10 }}>
              Annuler
            </button>
          </form>
        )}
      </Grid>
    </Grid>
  );
}
