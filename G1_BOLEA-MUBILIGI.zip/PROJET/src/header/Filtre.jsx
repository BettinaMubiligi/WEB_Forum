import React, { useState } from "react";
import "./Filtre.css";


//Composant de Filtre du Header qui prend le hanndler onFilter

const HeaderFilter = ({ onFilter }) => {
  const [query, setQuery] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    onFilter(query); 
  };

  return (
    <form className="filter-form" onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Filtrer contenu..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      <button type="submit">Search</button>
    </form>
  );
};

export default HeaderFilter;
