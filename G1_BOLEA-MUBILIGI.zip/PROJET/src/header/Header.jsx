import React from "react";
import HeaderTitle from "../header/ZoneTitre";
import HeaderFilter from "./Filtre";
import "./Header.css";


//Composant Header qui implémente les composnts de titre et le Filtre
const Header = ({ onFilter }) => {
  return (
    <header className="header">
      <HeaderTitle />
      <HeaderFilter onFilter={onFilter} />
    </header>
  );
};

export default Header;
