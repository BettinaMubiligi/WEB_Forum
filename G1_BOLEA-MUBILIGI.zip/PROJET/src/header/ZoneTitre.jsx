import React from "react";
import logo from "../assets/logoSorbonne.png"; 
import "./ZoneTitre.css";


//Zone de titre (composant) + logo de la fac
const HeaderTitle = () => {
  return (
    <div className="header-title">
      <img src={logo} alt="Project Logo" className="project-logo" />
      <h1>Organiz'asso</h1>
    </div>
  );
};

export default HeaderTitle;
