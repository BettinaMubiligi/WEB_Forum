import express from "express";
import { registerUser, loginUser } from "./entities/users.js";
import { ObjectId } from "mongodb";
import { createMessage, getMessages } from "./entities/messages.js";


//entité de gestion de l'api avec les routes/requetes de gestion du forum
export default function setupApi(db) {
  const router = express.Router();

  // Inscription : requete posrt pour renvoyer les identifianrs
  router.post("/api/users/register", async (req, res) => {
    const { email, password } = req.body;
    try {
      const user = await registerUser(db, email, password);
      res.status(201).json(user);
    } catch (err) {
      res.status(400).json({ message: err.message });
    }
  });

  // Connexion : pareil que inscription
  router.post("/api/users/login", async (req, res) => {
    const { email, password } = req.body;
    try {
      const { token, user } = await loginUser(db, email, password);
      res.json({ token, user });
    } catch (err) {
      res.status(400).json({ message: err.message });
    }
  });

  // requete get, Route pour récupérer les utilisateurs en attente de validation (pour les admins)
  router.get("/api/admin/pending-users", async (req, res) => {
    try {
      const users = await db.collection("users").find({ isValidated: false }).toArray();
      res.json(users);
    } catch (err) {
      res.status(500).json({ message: "Erreur lors de la récupération des demandes." });
    }
  });

  // Route pour valider/refuser un utilisateur
  router.post("/api/admin/validate-user", async (req, res) => {
    const { userId, validate } = req.body;
    try {
      await db.collection("users").updateOne(
        { _id: new ObjectId(userId) },
        { $set: { isValidated: !!validate } }
      );
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ message: "Erreur lors de la validation" });
    }
  });

  // requête POST pour créer un message (ou une réponse)
  router.post("/api/messages", async (req, res) => {
    const { content, authorEmail, authorRole, forumType, replyTo } = req.body;
    if (!content || !authorEmail || !forumType) {
      return res.status(400).json({ message: "Champs demandés manquants" });
    }
    try {
      const msg = await createMessage(db, { content, authorEmail, authorRole, forumType, replyTo });
      console.log("Création message", req.userId, req.body);
      res.status(201).json(msg);
    } catch (err) {
      res.status(500).json({ message: "erreur lors de la création du message." });
    }
  });

  // Récupérer les messages (tous, ou filtrés par auteur et/ou forum)
  router.get("/api/messages", async (req, res) => {
    const { author, forumType } = req.query;
    try {
      const messages = await getMessages(db, { authorEmail: author, forumType });
      res.json(messages);
    } catch (err) {
      res.status(500).json({ message: "Erreur lors de la récupération des messages." });
    }
  });
  // Supprimer un message par son _id et l'email de l'auteur (sécurité)
router.delete("/api/messages/:id", async (req, res) => {
  const { id } = req.params;
  const authorEmail = req.query.authorEmail; // Passe l'email en query pour vérifier

  if (!authorEmail) {
    return res.status(400).json({ message: "Email requis pour supprimer le message" });
  }

  try {
    const result = await db.collection("messages").deleteOne({
      _id: new ObjectId(id),
      authorEmail: authorEmail
    });
    if (result.deletedCount === 1) {
      res.json({ success: true });
    } else {
      res.status(403).json({ message: "Suppression impossible ou message introuvable" });
    }
  } catch (err) {
    res.status(500).json({ message: "Erreur lors de la suppression du message." });
  }
});


  return router;
}
