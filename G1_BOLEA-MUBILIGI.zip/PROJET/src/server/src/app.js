import express from "express";
import cors from "cors";
import { MongoClient } from "mongodb";
import setupApi from "./api.js";

//entité pour le lancement de la bdd
const app = express();
app.use(cors());
app.use(express.json());

const MONGO_URL = "mongodb://localhost:27017";
const DB_NAME = "organizasso";

console.log("on tente de connexion à MongoDB...");//test
MongoClient.connect(MONGO_URL)
  .then((client) => {
    console.log(" Connecté à MongoDB");
    const db = client.db(DB_NAME);
    app.use(setupApi(db));
    app.listen(3001, () => {
      console.log("Serveur backend sur http://localhost:3001");
    });
  })
  .catch((err) => {
    console.error("Erreur de connexion MongoDB:", err);
  });


export default app;
