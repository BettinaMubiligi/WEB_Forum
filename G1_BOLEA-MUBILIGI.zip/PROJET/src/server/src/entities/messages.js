
//entité pour manipuler les messages (serveur)
//fonction de création de msg dans la bdd
export async function createMessage(db, { content, authorEmail, authorRole, forumType, replyTo }) {
  const message = {
    content,
    authorEmail,
    authorRole,
    forumType,
    date: new Date(),
  };
  if (replyTo) message.replyTo = replyTo; //prend en compte les msg réponsse

  const result = await db.collection("messages").insertOne(message);
  return { ...message, _id: result.insertedId };
}
//on récupère les messages 
export async function getMessages(db, { authorEmail, forumType } = {}) {
  const filter = {};
  if (authorEmail) filter.authorEmail = authorEmail; //en fonction du mail
  if (forumType) filter.forumType = forumType; //en fonctiion du type de forum

  return db.collection("messages")
    .find(filter)
    .sort({ date: -1 })
    .limit(50) 
    .toArray();
}
