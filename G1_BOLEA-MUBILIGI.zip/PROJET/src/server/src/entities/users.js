import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

//entité pour la gestions  des users dans la bdd
//On a utilisé  bcrypt pour sécuriser le mdp dans la bdd
/*on autilisation un token avec une clé screte serveur pour sécuriser les infos de login de l’utilisateur*/

//fonction d'enregistrement d'utilisateur dans la bdd( Note : les comptes admins sont créés directement dans la bbd)
const SECRET_KEY = process.env.JWT_SECRET || "votre_secret_a_modifier";
export async function registerUser(db, email, password) {
  const existingUser = await db.collection("users").findOne({ email });
  if (existingUser) {
    throw new Error("un utilisateur avec cet email existe déjà.");
  }
  //on crypte le mdp
  const hashedPassword = await bcrypt.hash(password, 10);
  const result = await db.collection("users").insertOne({
    email,
    password: hashedPassword, //mdp chiffré dans la bdd (pour la sécurite)
    createdAt: new Date(),
    //statut automatique en false car seuls les admins décident 
    isAdmin: false,
    isValidated: false,
  });
  return {
    id: result.insertedId,
    email,
    isAdmin: false, 
    isValidated: false,
  };
}

//fonction de login d'un utilisateur (pour vérifier si ses Ids sont présents dans la bdd)
export async function loginUser(db, email, password) {
  const user = await db.collection("users").findOne({ email });
  if (!user) {
    throw new Error("Email ou mot de passe incorrect.");
  }
  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) {
    throw new Error("Email ou mot de passe incorrect.");
  }

  console.log("Mot de passe fourni:", password);
  console.log("Hash stocké:", user.password);
  const token = jwt.sign(
    {
      id: user._id,
      email: user.email,
      isAdmin: user.isAdmin,
    },
    SECRET_KEY,
    { expiresIn: "2h" }
  );
  return {
    token,
    user: {
      id: user._id,
      email: user.email,
      isAdmin: user.isAdmin,
      isValidated: user.isValidated,
    },
  };
}
