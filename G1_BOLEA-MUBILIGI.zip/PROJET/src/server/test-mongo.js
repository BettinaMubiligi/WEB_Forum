import { MongoClient } from "mongodb";
const MONGO_URL = "mongodb://localhost:27017";

console.log("Test de connexion à MongoDB...");
MongoClient.connect(MONGO_URL)
  .then(() => {
    console.log("Connexion OK");
    process.exit(0);
  })
  .catch((err) => {
    console.error("erreur connexion MongoDB:", err);
    process.exit(1);
  });
